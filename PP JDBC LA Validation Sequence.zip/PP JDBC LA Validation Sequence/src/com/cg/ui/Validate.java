package com.cg.ui;

public class Validate {
	boolean mailValidation(String email) {
		String regEx = "[a-zA-z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]{2,})+";
		if (email.matches(regEx))
			return true;
		else
			System.out.println("enter again");
		return false;
	}

	boolean phoneValidation(long phone) {
		String phoneno = Long.toString(phone); ///

		String regEx = "(91|0)?[6-9][0-9]{9}";
		if (phoneno.matches(regEx)) {
			return true;
		} else {
			System.out.println("enter again");
			return false;
		}

	}
}
