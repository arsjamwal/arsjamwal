package com.cg.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bean.Account;
//import com.cg.bean.Book;
//import com.cg.services.IAccountServices;
//import com.cg.services.IAccountServicesImpl;
import com.cg.services.IAccountServices;
import com.cg.services.AccountServicesImpl;

public class testAccount {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// Account a=new Account();
		IAccountServices O2 = new AccountServicesImpl();
		while (true) { //
			System.out.println("ACCOUNT SERVICES:\n" + "1. ACCOUNT\n" + "2. SHOW BALANCE\n" + "3. DEPOSIT\n"
					+ "4. WITHDRAW\n" + "5. FUND TRANSFER\n" + "6. PRINT TRANSACTIONS\n" + "7. EXIT");

			// int choice=0;
			System.out.println("choice no. :");
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				Validate v = new Validate();
				Account a = new Account();
				System.out.println("Enter details:");
				// System.out.println("Id:");
				// int id = sc.nextInt();
				// a.setId(sc.nextInt());
				System.out.println("name");
				String name = sc.next();
				// a.setName(sc.next());
				System.out.println("balance");
				long balance = sc.nextLong();
				// a.setBalance(sc.nextLong());
				System.out.println("email");
				// a.setEmail(sc.next());
				String email;
				do {
					email = sc.next();
				} while (!v.mailValidation(email));

				System.out.println("phone");
				long phone;
				do {
					phone = sc.nextLong();
				} while (!v.phoneValidation(phone));
				// a.setPhone(sc.nextLong()); ///

				// a.setId(id);
				a.setName(name);
				a.setBalance(balance);
				a.setEmail(email);
				a.setPhone(phone);

				O2.addAccount(a);
				break;
			case 2:
				O2.showBalance(sc.nextInt());
				break;
			case 3:
				O2.deposit(sc.nextInt(), sc.nextLong());
				break;
			case 4:
				O2.withdraw(sc.nextInt(), sc.nextLong());
				break;
			case 5:
				O2.fundTransfer(sc.nextInt(), sc.nextInt(), sc.nextLong());
				break;
			case 6:
				O2.printTransactions(sc.nextInt());
				break;
			case 7:
				System.out.println("exit");
				System.exit(0);
			}
		}
	}
}
