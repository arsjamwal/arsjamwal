package com.cg.repo;

//import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.Account;
//import com.cg.bean;
//import com.cg.bean.Book;
//import com.cg.bean.Transaction;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountRepoImpl implements IAccountRepo {
	private Connection con = null;
	private PreparedStatement ps = null;

	public void getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String user = "system";
		String pwd = "Capgemini123";
		con = DriverManager.getConnection(url, user, pwd);

	}

	@Override
	public void addAccount(Account a) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		getConnection();
		ps = con.prepareStatement("insert into account values(Accno.nextval,?,?,?,?)");
		// ps.setInt(1, a.getId());

		ps.setString(1, a.getName());
		ps.setLong(2, a.getBalance());
		ps.setString(3, a.getEmail());
		ps.setLong(4, a.getPhone());
		ps.executeUpdate();
		System.out.println("account created");
		ps = con.prepareStatement("select * from Account where phone=" + a.getPhone());
		ResultSet rs = ps.executeQuery();
		System.out.println("-------------");
		while (rs.next()) {
			System.out.println("Accno:");
			System.out.println(rs.getInt(1) + "\t" + rs.getString(2) + "\t" + rs.getLong(3) + "\t" + rs.getString(4)
					+ "\t" + rs.getLong(5));
		}
		con.close();

	}

	@Override
	public void showBalance(int id) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		getConnection();
		ps = con.prepareStatement("select balance from account where id=" + id);
		ResultSet rs = ps.executeQuery();
		rs.next();
		{
			System.out.println("balance:" + rs.getLong(1));
		}
		con.close();
	}

	@Override
	public void deposit(int id, long deposit) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		getConnection();
		ps = con.prepareStatement("select balance from Account where id=" + id);
		ResultSet rs = ps.executeQuery();
		ps = con.prepareStatement("update Account set balance=? where id=" + id);
		rs.next();
		long balance = rs.getLong(1) + deposit;
		ps.setLong(1, balance);
		// ps.executeUpdate();
		// System.out.println("deposited");
		ps.executeUpdate();
		System.out.println("deposited");

		ps = con.prepareStatement("insert into transactions values(?,?,?,?,?)");
		ps.setInt(1, id);
		ps.setLong(2, balance);
		ps.setString(3, "credited");
		ps.setDate(4, Date.valueOf(java.time.LocalDate.now()));
		ps.setLong(5, balance);
		ps.executeUpdate();

		con.close();
	}

	@Override
	public void withdraw(int id, long withdraw) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		getConnection();
		ps = con.prepareStatement("select balance from Account where id=" + id);
		ResultSet rs = ps.executeQuery();
		ps = con.prepareStatement("update Account set balance=? where id=" + id);
		rs.next();
		long balance = rs.getLong(1) - withdraw;
		ps.setLong(1, balance);
		ps.executeUpdate();
		System.out.println("withdrawn");

		ps = con.prepareStatement("insert into transactions values(?,?,?,?,?)");
		ps.setInt(1, id);
		ps.setLong(2, balance);
		ps.setString(3, "debited");
		ps.setDate(4, Date.valueOf(java.time.LocalDate.now()));
		ps.setLong(5, balance);
		ps.executeUpdate();

		con.close();
	}

	@Override
	public void fundTransfer(int id, int id2, long transfer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		getConnection();
		deposit(id, transfer);
		withdraw(id2, transfer);
		con.close();

	}

	@Override
	public void printTransactions(int id) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		getConnection();
		ps = con.prepareStatement("select * from Transactions where id=" + id);
		// ps.setLong(1, id);
		ResultSet rs = ps.executeQuery();
		System.out.println("-------------");
		while (rs.next()) {
			System.out.println(rs.getInt(1) + "\t" + rs.getLong(2) + "\t" + rs.getString(3) + "\t" + rs.getDate(4)
					+ "\t" + rs.getLong(5));
		}
		con.close();
	}
}