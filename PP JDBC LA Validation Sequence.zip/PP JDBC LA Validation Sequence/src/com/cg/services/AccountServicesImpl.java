package com.cg.services;

import java.sql.SQLException;

import com.cg.bean.Account;
import com.cg.repo.AccountRepoImpl;
import com.cg.repo.IAccountRepo;

public class AccountServicesImpl implements IAccountServices {
	IAccountRepo O1 = new AccountRepoImpl();

	@Override
	public void addAccount(Account a) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		O1.addAccount(a);
	}

	@Override
	public void showBalance(int id) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		O1.showBalance(id);
	}

	@Override
	public void deposit(int id, long deposit) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		O1.deposit(id, deposit);
	}

	@Override
	public void withdraw(int id, long withdraw) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		O1.withdraw(id, withdraw);
	}

	@Override
	public void fundTransfer(int id, int id2, long transfer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		O1.fundTransfer(id, id2, transfer);
	}

	@Override
	public void printTransactions(int id) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		O1.printTransactions(id);
	}

	// @Override
	// public void id() {
	// TODO Auto-generated method stub
	// O1.id();
	// }s

	// @Override
	// public void name() {
	// TODO Auto-generated method stub
	// O1.name();
	// }

}
