package com.cg.services;

import java.sql.SQLException;

import com.cg.bean.Account;

public interface IAccountServices {
	public void addAccount(Account a) throws ClassNotFoundException, SQLException;

	// public void id(/*int id*/);
	// public void name(/*String name*/);
	public void showBalance(int id) throws ClassNotFoundException, SQLException;

	public void deposit(int id, long deposit) throws ClassNotFoundException, SQLException;

	public void withdraw(int id, long withdraw) throws ClassNotFoundException, SQLException;

	public void fundTransfer(int id, int id2,long transfer) throws ClassNotFoundException, SQLException;

	public void printTransactions(int id) throws ClassNotFoundException, SQLException;
}
