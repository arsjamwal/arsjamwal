package com.cg.bean;

import java.util.ArrayList;

public class Account {
	private int id;
	private String name;
	private long balance;
	// private ArrayList<Transaction> trans = new ArrayList<>();

	// private long deposit;
	// private long withdraw;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	// public ArrayList<Transaction> getTrans() {
	// return trans;
	// }

	// public void setTrans(Transaction trans) {
	// this.trans.add(trans);

	@Override
	public String toString() {
		return "Account [id=" + id + ", name=" + name + ", balance=" + balance + "]";
	}

}